// $ANTLR : "jaql.g" -> "JaqlLexer.java"$

package com.ibm.jaql.lang.parser;

import java.util.*;

import com.ibm.jaql.lang.core.*;
import com.ibm.jaql.lang.expr.core.*;
import com.ibm.jaql.lang.expr.top.*;
import com.ibm.jaql.lang.expr.path.*;

import com.ibm.jaql.lang.expr.io.*;
import com.ibm.jaql.lang.expr.udf.*;
import com.ibm.jaql.lang.expr.record.IsdefinedExpr;
import com.ibm.jaql.lang.expr.array.ExistsFn;
import com.ibm.jaql.lang.expr.nil.IsnullExpr;
import com.ibm.jaql.lang.expr.agg.Aggregate;
import com.ibm.jaql.lang.expr.agg.AlgebraicAggregate;

import com.ibm.jaql.json.type.*;
import com.ibm.jaql.json.schema.*;
import com.ibm.jaql.json.util.*;
import com.ibm.jaql.lang.registry.*;

import com.ibm.jaql.util.*;


public interface JaqlTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int SEMI = 4;
	int LITERAL_explain = 5;
	int LITERAL_materialize = 6;
	int LITERAL_quit = 7;
	// "," = 8
	// "->" = 9
	int LITERAL_in = 10;
	int LITERAL_aggregate = 11;
	int LITERAL_agg = 12;
	int LITERAL_as = 13;
	int LITERAL_into = 14;
	int LITERAL_full = 15;
	int LITERAL_initial = 16;
	int LITERAL_partial = 17;
	int LITERAL_final = 18;
	// "[" = 19
	// "]" = 20
	int LITERAL_group = 21;
	int LITERAL_each = 22;
	int LITERAL_using = 23;
	int LITERAL_by = 24;
	// "=" = 25
	int LITERAL_expand = 26;
	int LITERAL_cmp = 27;
	// "(" = 28
	// ")" = 29
	int LITERAL_asc = 30;
	int LITERAL_desc = 31;
	int LITERAL_join = 32;
	int LITERAL_where = 33;
	int LITERAL_preserve = 34;
	int LITERAL_equijoin = 35;
	int LITERAL_on = 36;
	int LITERAL_split = 37;
	int LITERAL_if = 38;
	int LITERAL_else = 39;
	int LITERAL_filter = 40;
	int LITERAL_transform = 41;
	int LITERAL_top = 42;
	int LITERAL_unroll = 43;
	// "=>" = 44
	int LITERAL_extern = 45;
	int LITERAL_fn = 46;
	int LITERAL_script = 47;
	int LITERAL_import = 48;
	int LITERAL_for = 49;
	int LITERAL_sort = 50;
	// "{" = 51
	// "}" = 52
	// "?" = 53
	// ":" = 54
	int DOT_STAR = 55;
	int LITERAL_or = 56;
	int LITERAL_and = 57;
	int LITERAL_not = 58;
	int LITERAL_isnull = 59;
	int LITERAL_exists = 60;
	int LITERAL_isdefined = 61;
	// "==" = 62
	// "<" = 63
	// ">" = 64
	// "!=" = 65
	// "<=" = 66
	// ">=" = 67
	int LITERAL_instanceof = 68;
	// "+" = 69
	// "-" = 70
	// "*" = 71
	// "/" = 72
	int LITERAL_type = 73;
	int DOT = 74;
	int INT = 75;
	int DEC = 76;
	int DOUBLE = 77;
	int HEXSTR = 78;
	int DATETIME = 79;
	int LITERAL_true = 80;
	int LITERAL_false = 81;
	int LITERAL_null = 82;
	int STR = 83;
	int HERE_STRING = 84;
	int BLOCK_STRING = 85;
	int AVAR = 86;
	int VAR = 87;
	int ID = 88;
	int DOT_ID = 89;
	int FNAME = 90;
	// "|" = 91
	int DIGIT = 92;
	int HEX = 93;
	int LETTER = 94;
	int WS = 95;
	int COMMENT = 96;
	int NL = 97;
	int ML_COMMENT = 98;
	int BLOCK_LINE1 = 99;
	int HERE_TAG = 100;
	int HERE_LINE = 101;
	int HERE_END = 102;
	int VAR1 = 103;
	int SYM = 104;
	int SYM2 = 105;
	int STRCHAR = 106;
	int DOTTY = 107;
	int IDWORD = 108;
}

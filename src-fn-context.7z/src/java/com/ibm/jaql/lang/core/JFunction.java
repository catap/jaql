/*
 * Copyright (C) IBM Corp. 2008.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package com.ibm.jaql.lang.core;

import java.io.ByteArrayOutputStream;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.io.PrintStream;
import java.io.StringReader;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.HashSet;

import com.ibm.jaql.json.type.Item;
import com.ibm.jaql.json.type.JAtom;
import com.ibm.jaql.json.type.JValue;
import com.ibm.jaql.json.util.ClosingIter;
import com.ibm.jaql.json.util.Iter;
import com.ibm.jaql.lang.expr.core.DefineFunctionExpr;
import com.ibm.jaql.lang.expr.core.Expr;
import com.ibm.jaql.lang.parser.JaqlLexer;
import com.ibm.jaql.lang.parser.JaqlParser;

/**
 * 
 */
public class JFunction extends JAtom
{
  protected DefineFunctionExpr fn; // cannot have any captured variables
  protected boolean ownFn; // true if we own the fn, and therefore must init/close it.
  protected String fnText;

  /**
   * 
   */
  public JFunction()
  {
  }

  /**
   * @param params
   * @param body
   * @throws Exception
   */
  public JFunction(DefineFunctionExpr fn, boolean ownFn) throws Exception
  {
    set(fn, ownFn);
  }

  /**
   * @param params
   * @param body
   * @throws Exception
   */
  public void set(DefineFunctionExpr fn, boolean ownFn) throws Exception
  {
    this.fn = fn;
    this.ownFn = ownFn;

    ByteArrayOutputStream outStream = new ByteArrayOutputStream();
    PrintStream ps = new PrintStream(outStream);
    HashSet<Var> capturedVars = new HashSet<Var>();
    fn.decompile(ps, capturedVars);
    assert capturedVars.size() == 0;
    this.fnText = outStream.toString();
  }

  /**
   * @return
   */
  public int getNumParameters()
  {
    return fn.numParams();
  }

  /**
   * @return
   */
  public DefineFunctionExpr getFunction()
  {
    return fn;
  }

  /**
   * @return
   */
  public Expr getBody()
  {
    return fn.body();
  }
  
  /**
   * @param i
   * @return
   */
  public Var param(int i)
  {
    return fn.param(i).var;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.ibm.jaql.json.type.JValue#compareTo(java.lang.Object)
   */
  @Override
  public int compareTo(Object x)
  {
    // TODO: how are functions compared?  based on serialized text?
    throw new RuntimeException("functions cannot be compared");
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.ibm.jaql.json.type.JValue#getEncoding()
   */
  @Override
  public Item.Encoding getEncoding()
  {
    return Item.Encoding.FUNCTION;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.ibm.jaql.json.type.JValue#longHashCode()
   */
  @Override
  public long longHashCode()
  {
    throw new RuntimeException("functions cannot be hashed");
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.ibm.jaql.json.type.JAtom#print(java.io.PrintStream)
   */
  @Override
  public void print(PrintStream out)
  {
    out.print(fnText);
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.ibm.jaql.json.type.JValue#readFields(java.io.DataInput)
   */
  @Override
  public void readFields(DataInput in) throws IOException
  {
    fnText = in.readUTF();

    JaqlLexer lexer = new JaqlLexer(new StringReader(fnText)); // TODO: memory
    JaqlParser parser = new JaqlParser(lexer); // TODO: memory

    try
    {
      fn = (DefineFunctionExpr)parser.parse();
    }
    catch(Exception e)
    {
      fn = null;
      fnText = null;
      throw new UndeclaredThrowableException(e);
    }
    fn.annotate();
    ownFn = true;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.ibm.jaql.json.type.JValue#write(java.io.DataOutput)
   */
  @Override
  public void write(DataOutput out) throws IOException
  {
    out.writeUTF(fnText);
  }

  public Context initCall(Context callerContext)
  {
    Context fnContext = new Context(callerContext);
    // NOW: put captures into fnContext
    return fnContext;
  }

  protected void checkArgs(int numArgs)
  {
    int n = fn.numParams();
    if (n != numArgs)
    {
      throw new RuntimeException(
          "wrong number of arguments to function.  Expected " + n + " but given " + numArgs);
    }
  }

  public void setParams(Context fnContext, Item[] args, int offset, int length)
  {
    checkArgs(length);
    int p = fn.numParams();
    for(int i = 0 ; i < p ; i++)
    {
      fnContext.setValue(fn.param(i).var, args[offset + i]);
    }
  }

  public void setParams(Context fnContext, Expr[] args, int offset, int length) throws Exception
  {
    checkArgs(length);
    int p = fn.numParams();
    for(int i = 0 ; i < p ; i++)
    {
      fnContext.setExprEval(fn.param(i).var, args[offset + i]);
    }
  }

  public void setParamsGeneral(Context fnContext, Object[] args, int offset, int length) throws Exception
  {
    checkArgs(length);
    int p = fn.numParams();
    for(int i = 0 ; i < p ; i++)
    {
      fnContext.setGeneral(fn.param(i).var, args[offset + i]);
    }
  }
  
  /**
   * @param callerContext
   * @param args
   * @return
   * @throws Exception
   */
  public Item eval(Context callerContext, Item[] args) throws Exception
  {
    Context fnContext = initCall(callerContext);
    setParams(fnContext, args, 0, args.length);
    Item result = fn.body().eval(fnContext);
    fnContext.close();
    return result;
  }

  /**
   * @param callerContext
   * @param args
   * @param start index of first args to use
   * @param length number of args to use
   * @return
   * @throws Exception
   */
  public Item eval(Context callerContext, Expr[] args, int offset, int length) throws Exception
  {
    Context fnContext = initCall(callerContext);
    setParams(fnContext, args, offset, length);
    Item result = fn.body().eval(fnContext);
    fnContext.close();
    return result;
  }

  /**
   * @param callerContext
   * @param args Item, Iter, or Expr
   * @param start index of first args to use
   * @param length number of args to use
   * @return
   * @throws Exception
   */
  public Item evalGeneral(Context callerContext, Object[] args, int offset, int length) throws Exception
  {
    Context fnContext = initCall(callerContext);
    setParamsGeneral(fnContext, args, offset, length);
    Item result = fn.body().eval(fnContext);
    fnContext.close();
    return result;
  }

  /**
   * Requires:
   *    * initCall has been called to create the fnContext
   *    * all parameters have been set in the fnContext using
   *        * setParams(...)
   *        * fnContext.set...(param(i), value)
   *    * the caller will call fnContext.close()
   *    
   * Allows multiple eval calls with the same fnContext.
   * 
   * @param fnContext
   * @return
   * @throws Exception
   */
  public Item eval(Context fnContext) throws Exception
  {
    return fn.body().eval(fnContext);
  }

  /**
   * @param callerContext
   * @param args
   * @return
   * @throws Exception
   */
  public Iter iter(Context callerContext, Item[] args) throws Exception
  {
    Context fnContext = initCall(callerContext);
    setParams(fnContext, args, 0, args.length);
    Iter iter = fn.body().iter(fnContext);
    return new ClosingIter(iter, fnContext);
  }

  /**
   * @param callerContext
   * @param args
   * @return
   * @throws Exception
   */
  public Iter iter(Context callerContext, Expr[] args, int start, int length) throws Exception
  {
    Context fnContext = initCall(callerContext);
    setParams(fnContext, args, start, length);
    Iter iter = fn.body().iter(fnContext);
    return new ClosingIter(iter, fnContext);
  }

  /**
   * 
   * @param callerContext
   * @param args
   * @return
   * @throws Exception
   */
  public Iter iter(Context callerContext, Expr[] args) throws Exception
  {
    return iter(callerContext, args, 0, args.length);
  }

  /**
   * 
   * @param callerContext
   * @param arg0
   * @param arg1
   * @return
   * @throws Exception
   */
  public Iter iter(Context callerContext, Item arg0, Item arg1) throws Exception
  {
    checkArgs(2);
    Context fnContext = initCall(callerContext);
    fnContext.setValue(param(0), arg0);
    fnContext.setValue(param(1), arg1);
    Iter iter = fn.body().iter(fnContext);
    return new ClosingIter(iter, fnContext);
  }

  /**
   * 
   * @param callerContext
   * @param arg0
   * @return
   * @throws Exception
   */
  public Iter iter(Context callerContext, Iter arg0) throws Exception
  {
    checkArgs(1);
    Context fnContext = initCall(callerContext);
    fnContext.setIter(param(0), arg0);
    Iter iter = fn.body().iter(fnContext);
    return new ClosingIter(iter, fnContext);
  }

  /**
   * 
   * @param callerContext
   * @param arg0
   * @param arg1
   * @return
   * @throws Exception
   */
  public Iter iter(Context callerContext, Item arg0, Iter arg1) throws Exception
  {
    checkArgs(2);
    Context fnContext = initCall(callerContext);
    fnContext.setValue(param(0), arg0);
    fnContext.setIter(param(1), arg1);
    Iter iter = fn.body().iter(fnContext);
    return new ClosingIter(iter, fnContext);
  }

  /**
   * Requires:
   *    * initCall has been called to create the fnContext
   *    * all parameters have been set in the fnContext using
   *        * setParams(...)
   *        * fnContext.set...(param(i), value)
   *    * Does NOT allow multiple iter() calls with the same fnContext
   * 
   * @param fnContext
   * @return
   * @throws Exception
   */
  public Iter iter(Context fnContext) throws Exception
  {
    return fn.body().iter(fnContext);
  }


  /*
   * (non-Javadoc)
   * 
   * @see com.ibm.jaql.json.type.JValue#copy(com.ibm.jaql.json.type.JValue)
   */
  @Override
  public void setCopy(JValue jvalue) throws Exception
  {
    JFunction f = (JFunction) jvalue;
    this.fn = (DefineFunctionExpr)f.fn.clone(new VarMap(null));
    this.ownFn = true;
    this.fnText = f.fnText;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.ibm.jaql.json.type.JValue#toJSON()
   */
  @Override
  public String toJSON()
  {
    return fnText; // TODO: wrap in constructor?
  }

}

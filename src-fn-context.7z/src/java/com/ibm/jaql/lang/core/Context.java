/*
 * Copyright (C) IBM Corp. 2008.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package com.ibm.jaql.lang.core;

import java.io.Closeable;
import java.io.IOException;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.ArrayList;
import java.util.HashMap;

import com.ibm.jaql.json.type.Item;
import com.ibm.jaql.json.type.JArray;
import com.ibm.jaql.json.type.SpillJArray;
import com.ibm.jaql.json.util.Iter;
import com.ibm.jaql.lang.core.Var.Usage;
import com.ibm.jaql.lang.expr.core.Expr;
import com.ibm.jaql.lang.util.JaqlUtil;

/** Run-time context, i.e., values for the variables in the environment.
 * 
 */
public class Context implements Closeable
{
  protected Context parent;
  protected HashMap<Var,Object> varValues = new HashMap<Var,Object>();
  protected HashMap<Expr,Item>  tempArrays = new HashMap<Expr,Item>(); // TODO: we could use one hashmap
  // PyModule pyModule;

  /**
   * Create a new root context.
   */
  public Context()
  {
    
  }
  
  /**
   * Create a child context.
   */
  public Context(Context parent)
  {
    this.parent = parent;
//    if( JaqlUtil.getSessionContext() == null )
//    {
//      PySystemState systemState = Py.getSystemState();
//      if (systemState == null)
//      {
//        systemState = new PySystemState();
//      }
//      Py.setSystemState(systemState);
//      pyModule = new PyModule("jaqlMain", new PyStringMap());
//    }
  }

  // public PyModule getPyModule() { return JaqlUtil.getSessionContext().pyModule; }
  
  /** Clears the context.
   * 
   */
  public void reset()
  {
    varValues.clear();
    tempArrays.clear();
    JaqlUtil.getQueryPageFile().clear();
  }
  
  /**
   * 
   * @param var
   * @return
   * @throws Exception 
   */
  public Item getValue(Var var) throws Exception
  {
    Context ctx = this;
    do
    {
      Object obj = ctx.varValues.get(var);
      if( obj instanceof Item )
      {
        return (Item)obj;
      }
      else if( obj instanceof Iter )
      {
        SpillJArray arr = new SpillJArray();
        arr.setCopy((Iter)obj);
        Item value = new Item(arr);
        ctx.setValue(var, value);
        return value;
      }
      else if( obj instanceof Expr ) // only possible for lazy global vars
      {
        Expr expr = (Expr)obj;
        Item value = expr.eval(ctx);       // TODO: init/close calls.
        ctx.setValue(var, value);
        return value;
      }
      ctx = ctx.parent;
    }
    while( ctx != null );
    
    throw new NullPointerException("undefined variable: "+var.name());
  }

  /**
   * Return an iterator over the (array) value.
   * If the value is not an array, an exception is raised.
   * If this variable has STREAM usage, it is NOT safe to request the value multiple times.
   * 
   * @return
   * @throws Exception
   */
  public Iter getIter(Var var) throws Exception
  {
    Context ctx = this;
    do
    {
      Object obj = ctx.varValues.get(var);
      if( obj instanceof Item )
      {
        Item value = (Item)obj;
        JArray arr = (JArray)value.get(); // cast error intentionally possible
        if( arr == null )
        {
          return Iter.nil;
        }
        return arr.iter();
      }
      else if( obj instanceof Iter )
      {
        Iter iter = (Iter)obj;
        if( var.usage == Usage.STREAM )
        {
          ctx.varValues.put(var,null); // set undefined
          return iter;
        }
        else
        {
          SpillJArray arr = new SpillJArray();
          arr.setCopy(iter);
          Item value = new Item(arr);
          ctx.setValue(var, value);
          return arr.iter();
        }
      }
      else if( obj instanceof Expr ) // only possible for lazy global vars
      {
        Expr expr = (Expr)obj;
        return expr.iter(ctx);       // TODO: init/close calls.
      }
      ctx = ctx.parent;
    }
    while( ctx != null );
    
    throw new NullPointerException("undefined variable: "+var.name());
  }

  /**
   * 
   * @param var
   * @param value
   */
  public void setValue(Var var, Item value)
  {
    assert value != null;
    varValues.put(var, value);
  }

  /**
   * 
   * @param var
   * @param value
   */
  public void setIter(Var var, Iter iter)
  {
    assert iter != null;
    assert var.usage == Usage.STREAM; // TODO: is this required?
    varValues.put(var, iter);
  }

  /**
   * Set the variable to be the expression, but do not evaluate it until it's value is requested.
   * This only works in for global variables (because dependent variable values are not captured).
   * 
   * @param var
   * @param expr
   */
  public void setExprDef(Var var, Expr expr)
  {
    varValues.put(var, expr);
  }
  
  /**
   * Set the variable's value to the result of the expression.
   * If the variable is unused, the expression is not evaluated.
   * If the variable is streamable and the expression is known to produce an array. 
   * 
   * @param expr
   * @param context
   * @throws Exception
   */
  public void setExprEval(Var var, Expr expr) throws Exception
  {
    // TODO: should the usage be STREAM only if it is used in an array context?
    if( var.usage == Usage.STREAM && expr.isArray().always() ) 
    {
      setIter(var, expr.iter(this));
    }
    else if( var.usage != Usage.UNUSED )
    {
      setValue(var, expr.eval(this));
    }
  }
  
  /**
   * 
   * @param var
   * @param value
   * @throws Exception
   */
  public void setGeneral(Var var, Object value) throws Exception
  {
    if( value instanceof Item )
    {
      setValue(var, (Item)value);
    }
    else if( value instanceof Iter )
    {
      setIter(var, (Iter)value);
    }
    else if( value instanceof Expr )
    {
      setExprEval(var, (Expr)value);
    }
    else
    {
      throw new RuntimeException("internal error: invalid variable value: "+value);
    }
  }

  public Item getTempArray(Expr expr)
  {
    Item tempItem = tempArrays.get(expr);
    if( tempItem == null )
    {
      tempItem = new Item(new SpillJArray());
      tempArrays.put(expr, tempItem);
    }
    return tempItem;
  }

//  /** UNUSED 
//   * @param item
//   * @return
//   * @throws Exception
//   */
//  public Item makeSessionGlobal(Item item) throws Exception
//  {
//    Item global = new Item();
//    if (item.isAtom())
//    {
//      global.copy(item); // TODO: copy should take a pagefile
//    }
//    else // FIXME: this is not doing what it is supposed to do 
//    {
//      PagedFile pf = JaqlUtil.getSessionPageFile(); // TODO: this is BROKEN!
//      SpillFile sf = new SpillFile(pf);
//      item.write(sf);
//      global.readFields(sf.getInput());      
//    }
//    return global;
//  }

  protected ArrayList<Runnable> atClose = new ArrayList<Runnable>();
  public void doAtClose(Runnable task)
  {
    atClose.add(task);
  }
  
  public void close()
  {
    reset();
    for(Runnable task: atClose)
    {
      try
      {
        task.run();
      }
      catch(Throwable e)
      {
        e.printStackTrace(); // TODO: log
      }
    }
    atClose.clear();
  }

  /**
   * In case a context gets lost, we will close it when garbage collected.
   * This can happen when exceptions occur or because functions that return an Iter
   * might not be run until completion (which is when they close their context).
   */
  protected void finalize() throws Throwable 
  {
    try
    {
      close();
    }
    finally
    {
      super.finalize();
    }
  }

  public void closeAtQueryEnd(final Closeable resource)
  {
    doAtClose(new Runnable() {
      @Override
      public void run()
      {
        try
        {
          resource.close();
        }
        catch (IOException e)
        {
          throw new UndeclaredThrowableException(e);
        }
      }
    });
  }

}

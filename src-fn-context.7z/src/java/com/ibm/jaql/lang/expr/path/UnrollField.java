/*
 * Copyright (C) IBM Corp. 2009.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package com.ibm.jaql.lang.expr.path;

import java.io.PrintStream;
import java.util.HashSet;

import com.ibm.jaql.json.type.Item;
import com.ibm.jaql.json.type.JRecord;
import com.ibm.jaql.json.type.JString;
import com.ibm.jaql.json.type.MemoryJRecord;
import com.ibm.jaql.lang.core.Context;
import com.ibm.jaql.lang.core.Var;
import com.ibm.jaql.lang.expr.core.Expr;


public class UnrollField extends UnrollStep
{
  /**
   * @param exprs
   */
  public UnrollField(Expr[] exprs)
  {
    super(exprs);
  }

  /**
   * @param field
   */
  public UnrollField(Expr field)
  {
    super(field);
  }

  /**
   * 
   */
  public void decompile(PrintStream exprText, HashSet<Var> capturedVars)
  throws Exception
  {
    exprText.print(".(");
    exprs[0].decompile(exprText, capturedVars);
    exprText.print(")");
  }

  /* (non-Javadoc)
   * @see com.ibm.jaql.lang.expr.core.ExpandStep#eval(com.ibm.jaql.lang.core.Context)
   */
  @Override
  public Item expand(Context context, Item toExpand) throws Exception
  {
    JRecord rec = (JRecord)toExpand.get();
    if( rec == null )
    {
      return null;
    }
    JString ename = (JString)exprs[0].eval(context).get();
    if( ename == null )
    {
      return null;
    }
    int n = rec.arity();
    MemoryJRecord out = new MemoryJRecord(n); // TODO: memory
    Item hole = null;
    for(int i = 0 ; i < n ; i++)
    {
      JString name = rec.getName(i);
      Item value = rec.getValue(i);
      if( name.equals(ename) )
      {
        value = hole = new Item(value.get()); // TODO: memory
      }
      out.add(name, value);
    }
    toExpand.set(out);
    return hole;
  }
}

/*
 * Copyright (C) IBM Corp. 2009.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package com.ibm.jaql.lang.expr.agg;

import com.ibm.jaql.json.type.Item;
import com.ibm.jaql.json.type.JArray;
import com.ibm.jaql.json.type.JNumber;
import com.ibm.jaql.json.type.SpillJArray;
import com.ibm.jaql.json.util.Iter;
import com.ibm.jaql.lang.core.Context;
import com.ibm.jaql.lang.expr.core.Expr;
import com.ibm.jaql.lang.expr.core.JaqlFn;

/**
 * 
 */
@JaqlFn(fnName = "pickN", minArgs = 2, maxArgs = 2)
public final class PickNAgg extends AlgebraicAggregate // TODO: should this preserve nulls?
{
  private SpillJArray array = new SpillJArray();
  private long limit;
  
  /**
   * Expr aggInput, Expr N
   * @param exprs
   */
  public PickNAgg(Expr[] exprs)
  {
    super(exprs);
  }

  /**
   * @param expr
   */
  public PickNAgg(Expr expr)
  {
    super(expr);
  }

  @Override
  public void initInitial(Context context) throws Exception
  {
    array.clear();
    JNumber num = (JNumber)exprs[1].eval(context).get();
    limit = num.longValueExact();
  }

  @Override
  public void addInitial(Item item) throws Exception
  {
    if( item.isNull() )
    {
      return;
    }
    if( array.count() < limit )
    {
      array.addCopy(item);
    }
  }

  @Override
  public Item getPartial() throws Exception
  {
    return new Item(array);
  }

  @Override
  public void addPartial(Item item) throws Exception
  {
    JArray array2 = (JArray)item.get();
    long m = array.count();
    long n = array2.count();
    Iter iter = array2.iter();
    if( m + n < limit )
    {
      array.addCopyAll(iter);
    }
    else
    {
      for( ; m < limit ; m++ )  
      {
        array.addCopy(iter.next()); // TODO: we will find all of them
      }
    }
  }

  @Override
  public Item getFinal() throws Exception
  {
    return getPartial();
  }
}

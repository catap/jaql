from distutils.core import setup
import os, os.path, sys

class pyJaqlSetup:
	#def setupWindows(self)
	#def setupLinux(self)
	#def setupMac(self)
	def setup(self):
		setup(
			name = 'pyJaql',
			package_dir={'pyJaql': 'pyJaql','pyJaql.ut':'pyJaql/ut'},
			#install packages		    	
			packages = ['pyJaql','pyJaql.ut'],
			#configurate file			
			package_data={'pyJaql': ['ut/*.jql']},
		    	version = '0.1',
		    	description = 'jaql - python - bridge',
		    	author='impliance-jaql-IBM',
		    	author_email='impliance-jaql@cs.opensource.ibm.com'
		)

module = pyJaqlSetup()
module.setup()


